       implicit double precision(a-h,o-z)
       parameter(ind=4999,ine=49999)
       dimension ne(ine,3)
       dimension xx(ind),yy(ind),zz(ind)
       character*32 rfile
c
       rfile='grid.inp'
       open(1,file=rfile)
       read(1,*)np
       read(1,*)(i,xx(i),yy(i),zz(i),i=1,np)
       close(1)
c
       call mesh(np,xx,yy,ne)
c
       stop
       end
c-----------------------------------------------------------------------
c
c      �f���[�j�����ŗv�f�𔭐�������
c
c      ����
c      np    :�ߓ_��
c      xx(np):x���W
c      yy(np):y���W
c
c      �߂�l
c      nele      :�v�f��
c      ne(nele,3):�v�f���̐ߓ_�ԍ�
c
c      �����ϐ�
c      nb(np)      0:�c���ߓ_,1:��ō폜����ߓ_
c      nl         :�ߓ_i���O�ډ~���Ɋ܂ޗv�f��
c      ml(nl)     :�ߓ_i���O�ډ~���Ɋ܂ޗv�f�ԍ�
c      nm         :�ӂ̐�
c      mm(nm,2)   :�ӂ�2�̒��_�̔ԍ�
c      lm(nm)      0:���L���Ȃ���,1:���L�����  ��0�̕ӂŗv�f���쐬����
c      ne0(nel0,3):�v�f�폜�p
c      ind        :�ߓ_���̏��
c      ine        :�v�f���̏��
c      nk         :���v�_�̐�
c      mk(nk)     :���v�_�̐ߓ_�ԍ�
c      np0        :�V�����ߓ_��
c      x0(np0)    :�V����x���W
c      y0(np0)    :�V����y���W
c      z0(np0)    :�V����z���W
c      m0(np)     :�V�����ߓ_�ԍ�
c
c-----------------------------------------------------------------------
       subroutine mesh(np,xx,yy,ne)
       implicit double precision(a-h,o-z)
       parameter(ind=4999,ine=49999)
       dimension ne(ine,3)
       dimension xx(ind),yy(ind)
c
c      �����ϐ�
       dimension nb(ind)
       dimension ml(ine)
       dimension mm(ind,2),lm(ind)
       dimension ne0(ine,3)
       dimension mk(ind)
       dimension m0(ind)
       dimension x0(ind),y0(ind),z0(ind)
c
c      �͈͂����߂�
       xmin= 999d0
       xmax=-999d0
       ymin= 999d0
       ymax=-999d0
       do i=1,np
         nb(i)=0    !�c���ߓ_
         if(xx(i).lt.xmin)xmin=xx(i)
         if(xx(i).gt.xmax)xmax=xx(i)
         if(yy(i).lt.ymin)ymin=yy(i)
         if(yy(i).gt.ymax)ymax=yy(i)
       enddo
c
       xmin=xmin-(xmax-xmin)*2d0
       xmax=xmax+(xmax-xmin)*2d0
       ymin=ymin-(ymax-ymin)*2d0
       ymax=ymax+(ymax-ymin)*2d0
       write(*,*)sngl(xmin),sngl(ymin),sngl(xmax),sngl(ymax)
c
c      �_�~�[�ߓ_


c
c      �ߓ_�̐ݒ�
       np=np+1
       xx(np)=xmin
       yy(np)=ymin
       nb(np)=1  !��ō폜����ߓ_

       np=np+1
       xx(np)=xmax
       yy(np)=ymin
       nb(np)=1

       np=np+1
       xx(np)=xmax
       yy(np)=ymax
       nb(np)=1

       np=np+1
       xx(np)=xmin
       yy(np)=ymax
       nb(np)=1
c
c      �v�f�̐ݒ�
       nele=1
       ne(nele,1)=np-3
       ne(nele,2)=np-2
       ne(nele,3)=np-1

       nele=2
       ne(nele,1)=np-3
       ne(nele,2)=np-1
       ne(nele,3)=np-0
c
       call pltne(0,np,nele,ne,xx,yy,ind,ine)
c
c      �f���[�j�������s��
       do 100 i=1,np-4
         write(*,*)"----"
         write(*,*)"loop:",i,np-4,nele
c
c        �폜���Ȃ��ߓ_
c         nb(i)=0
c
c        �ߓ_���O�ډ~���Ɋ܂ޗv�f
c        nl,ml(nl)
         nl=0
         do kele=1,nele
           x1=xx(ne(kele,1))
           x2=xx(ne(kele,2))
           x3=xx(ne(kele,3))
           y1=yy(ne(kele,1))
           y2=yy(ne(kele,2))
           y3=yy(ne(kele,3))
c          �O�ډ~�̒��S�Ɣ��a���v�Z����
           call circum(x1,x2,x3,y1,y2,y3,rr,x,y)
c
           r=dsqrt((x-xx(i))**2+(y-yy(i))**2)
           if(r.lt.rr-1d-12)then
             nl=nl+1
             ml(nl)=kele
           endif
         enddo
c
c         do kl=1,nl
c           write(*,*)"ne:",kl,ml(kl)
c     &                     ,ne(ml(kl),1),ne(ml(kl),2),ne(ml(kl),3)
c         enddo
c         pause
c
c        ���L���Ȃ��ӂ�T��
c        nm,mm(nm,2),lm(nm)
         nm=0
         do kl=1,nl !�O�ډ~���ɐߓ_���܂ޗv�f
           kele=ml(kl)
c          ��1
           nm=nm+1
           mm(nm,1)=ne(kele,1)
           mm(nm,2)=ne(kele,2)
           lm(nm)=0
c          ��2
           nm=nm+1
           mm(nm,1)=ne(kele,2)
           mm(nm,2)=ne(kele,3)
           lm(nm)=0
c          ��3
           nm=nm+1
           mm(nm,1)=ne(kele,3)
           mm(nm,2)=ne(kele,1)
           lm(nm)=0
c
c          �d���m�F
           do 200 jl=1,nl
             if(kl.eq.jl)goto 200
             jele=ml(jl)
             j1=ne(jele,1)
             j2=ne(jele,2)
             j3=ne(jele,3)           
c            ��1
             if(mm(nm-2,1).eq.j1 .and. mm(nm-2,2).eq.j2)lm(nm-2)=1
             if(mm(nm-2,1).eq.j2 .and. mm(nm-2,2).eq.j3)lm(nm-2)=1
             if(mm(nm-2,1).eq.j3 .and. mm(nm-2,2).eq.j1)lm(nm-2)=1
             if(mm(nm-2,2).eq.j1 .and. mm(nm-2,1).eq.j2)lm(nm-2)=1
             if(mm(nm-2,2).eq.j2 .and. mm(nm-2,1).eq.j3)lm(nm-2)=1
             if(mm(nm-2,2).eq.j3 .and. mm(nm-2,1).eq.j1)lm(nm-2)=1
c            ��2
             if(mm(nm-1,1).eq.j1 .and. mm(nm-1,2).eq.j2)lm(nm-1)=1
             if(mm(nm-1,1).eq.j2 .and. mm(nm-1,2).eq.j3)lm(nm-1)=1
             if(mm(nm-1,1).eq.j3 .and. mm(nm-1,2).eq.j1)lm(nm-1)=1
             if(mm(nm-1,2).eq.j1 .and. mm(nm-1,1).eq.j2)lm(nm-1)=1
             if(mm(nm-1,2).eq.j2 .and. mm(nm-1,1).eq.j3)lm(nm-1)=1
             if(mm(nm-1,2).eq.j3 .and. mm(nm-1,1).eq.j1)lm(nm-1)=1
c            ��3
             if(mm(nm-0,1).eq.j1 .and. mm(nm-0,2).eq.j2)lm(nm-0)=1
             if(mm(nm-0,1).eq.j2 .and. mm(nm-0,2).eq.j3)lm(nm-0)=1
             if(mm(nm-0,1).eq.j3 .and. mm(nm-0,2).eq.j1)lm(nm-0)=1
             if(mm(nm-0,2).eq.j1 .and. mm(nm-0,1).eq.j2)lm(nm-0)=1
             if(mm(nm-0,2).eq.j2 .and. mm(nm-0,1).eq.j3)lm(nm-0)=1
             if(mm(nm-0,2).eq.j3 .and. mm(nm-0,1).eq.j1)lm(nm-0)=1
200        continue
         enddo
c
c         do km=1,nm
c           if(lm(km).eq.0)write(*,*)"km:",km,mm(km,1),mm(km,2)
c         enddo
c         pause
c
c        ���L���Ȃ��ӂŗv�f���쐬
         do 300 km=1,nm !���L���Ȃ���
           if(lm(km).eq.1)goto 300
           nele=nele+1
           ne(nele,1)=i
           ne(nele,2)=mm(km,1)
           ne(nele,3)=mm(km,2)
300      continue
c
c        �ߓ_���O�ډ~���Ɋ܂ޗv�f���폜����
c        nl,ml(nl)
         nel0=0
         do 400 kele=1,nele
           do kl=1,nl
             if(ml(kl).eq.kele)goto 400
           enddo
           nel0=nel0+1
           ne0(nel0,1)=ne(kele,1)
           ne0(nel0,2)=ne(kele,2)
           ne0(nel0,3)=ne(kele,3)
c           write(*,*)"ne0:",nel0,ne0(nel0,1),ne0(nel0,2),ne0(nel0,3)
400      continue
c
         nele=nel0
         do kele=1,nele
           ne(kele,1)=ne0(kele,1)
           ne(kele,2)=ne0(kele,2)
           ne(kele,3)=ne0(kele,3)
         enddo
c
         call pltne(i,np,nele,ne,xx,yy,ind,ine)
c
100    continue    !���C�����[�v
c
c----------------------------------------------------------------------
c
c      �ŏ��̗v�f�E�ߓ_���폜
       nel0=0
       do 700 kele=1,nele
         if(nb(ne(kele,1)).eq.1)goto 700
         if(nb(ne(kele,2)).eq.1)goto 700
         if(nb(ne(kele,3)).eq.1)goto 700
         nel0=nel0+1
         ne0(nel0,1)=ne(kele,1)
         ne0(nel0,2)=ne(kele,2)
         ne0(nel0,3)=ne(kele,3)
700    continue
c
       nele=nel0
       do kele=1,nele
         ne(kele,1)=ne0(kele,1)
         ne(kele,2)=ne0(kele,2)
         ne(kele,3)=ne0(kele,3)
       enddo
c
c----------------------------------------------------------------------
c
c      ���v�_�̊m�F
c      ��U�v�f�̐ߓ_�ɂȂ�����A���p�`���Ɏc�����ߓ_��T��
       nk=0
       do 500 i=1,np
         do kele=1,nele
           if(i.eq.ne(kele,1))goto 500
           if(i.eq.ne(kele,2))goto 500
           if(i.eq.ne(kele,3))goto 500
         enddo
         nk=nk+1
         mk(nk)=i
500    continue
       write(*,*)"���v�_:",nk
c
c      ���v�_���폜����
       np0=0
       do 600 i=1,np
         do kk=1,nk
           if(i.eq.mk(kk))goto 600
         enddo
         np0=np0+1
         x0(np0)=xx(i)
         y0(np0)=yy(i)
         m0(i)=np0
600    continue
c
       np=np0
       do i=1,np
         xx(i)=x0(i)
         yy(i)=y0(i)
       enddo
c
       do kele=1,nele
         ne(kele,1)=m0(ne(kele,1))
         ne(kele,2)=m0(ne(kele,2))
         ne(kele,3)=m0(ne(kele,3))
       enddo
c
       call pltne(1,np,nele,ne,xx,yy,ind,ine)
c
c----------------------------------------------------------------------
c
c      �t�@�C���쐬
       open(1,file='mesh.inp')
       write(1,*)np,nele
       do kp=1,np
         write(1,*)kp,xx(kp),yy(kp)
       enddo
c
       do kele=1,nele
         write(1,*)kele,ne(kele,1),ne(kele,2),ne(kele,3),1
       enddo       
       close(1)
c
       return
       end
c-------------------------------------------------------------------------------
c
c          �O�ډ~�̒��S�Ɣ��a���v�Z����
c
c          ����
c          x1,x2,x3,y1,y2,y3
c
c          �߂�l
c          rr :�O�ډ~�̔��a
c          x,y:�O�ډ~�̒��S���a
c
c-------------------------------------------------------------------------------
       subroutine circum(x1,x2,x3,y1,y2,y3,rr,x,y)
       implicit double precision(a-h,o-z)
c
c      �ӂ̒���
       a=dsqrt((x2-x3)**2+(y2-y3)**2)
       b=dsqrt((x3-x1)**2+(y3-y1)**2)
       c=dsqrt((x1-x2)**2+(y1-y2)**2)
c
c      �ʐ�
       ar=artri(x1,y1,0d0,x2,y2,0d0,x3,y3,0d0)
c
c      �O�ډ~�̒��S
       x=a**2*(b**2+c**2-a**2)*x1
     &  +b**2*(c**2+a**2-b**2)*x2
     &  +c**2*(a**2+b**2-c**2)*x3
       x=x/16d0/ar**2
       y=a**2*(b**2+c**2-a**2)*y1
     &  +b**2*(c**2+a**2-b**2)*y2
     &  +c**2*(a**2+b**2-c**2)*y3
       y=y/16d0/ar**2
c
c      �O�ډ~�̔��a
       r1=dsqrt((x1-x)**2+(y1-y)**2)
       r2=dsqrt((x2-x)**2+(y2-y)**2)
       r3=dsqrt((x3-x)**2+(y3-y)**2)
       rr=(r1+r2+r3)/3d0
c
c      ���Z
       if(dabs(r1-rr).gt.1d-5 .or.
     &    dabs(r2-rr).gt.1d-5 .or. 
     &    dabs(r3-rr).gt.1d-5)then
          write(*,*)"circum"
          write(*,*)"radian is different"
          write(*,*)"r:",sngl(r1),sngl(r2),sngl(r3),sngl(rr)
          stop
        endif
c
       return
       end
c------------------------------------------------------------
c
c       3�p�`�̖ʐ�
c
c------------------------------------------------------------
        function artri(x1,y1,z1,x2,y2,z2,x3,y3,z3)
        implicit double precision(a-h,o-z)
c
        vx=(y1-y3)*(z2-z3)-(z1-z3)*(y2-y3)
        vy=(z1-z3)*(x2-x3)-(x1-x3)*(z2-z3)
        vz=(x1-x3)*(y2-y3)-(y1-y3)*(x2-x3)
        artri=dsqrt(vx**2+vy**2+vz**2)/2d0
        return
        end

