c------------------------------------------------------------------
c
c       �f�[�^�쐬
c
c       �����A�߂�l
c       np    :�ߓ_��
c       xx(np):x���W
c       yy(np):y���W
c       zz(np):z���W
c       rr(np):�ߓ_���a
c       nb(np) 0:�����ߓ_,1:���E�ߓ_
c       r0    :��̐ߓ_���a
c       ind   :�ߓ_���̏��
c------------------------------------------------------------------
       subroutine data_square3(np,xx,yy,zz,rr,nb,r0,ind)
       implicit double precision(a-h,o-z)
       dimension xx(ind),yy(ind),zz(ind),rr(ind)
       dimension nb(ind)

c      �����ϐ�
c      double x,y,z,r
c      int i,j,n

       np=0
       x=0d0
       y=0d0
       z=0d0
       r=1d-1

       n=10	!������

c      ���E�̐ߓ_

c      ��
       do i=1,n+1
       do j=1,n+1
         np=np+1
         xx(np)=dble(i-1)/dble(n)
         yy(np)=dble(j-1)/dble(n)
         zz(np)=0d0
         rr(np)=r
         nb(np)=1
       enddo
       enddo

c      ��
       do i=1,n+1
       do j=1,n+1
         np=np+1
         xx(np)=dble(i-1)/dble(n)
         yy(np)=dble(j-1)/dble(n)
         zz(np)=1d0
         rr(np)=r
         nb(np)=1
       enddo
       enddo

c      ��
       do i=1,n+1
       do j=2,n
         np=np+1
         xx(np)=dble(i-1)/dble(n)
         yy(np)=0d0
         zz(np)=dble(j-1)/dble(n)
         rr(np)=r
         nb(np)=1
       enddo
       enddo

c      �E
       do i=1,n+1
       do j=2,n
         np=np+1
         xx(np)=dble(i-1)/dble(n)
         yy(np)=1d0
         zz(np)=dble(j-1)/dble(n)
         rr(np)=r
         nb(np)=1
       enddo
       enddo

c      ��O
       do i=2,n
       do j=2,n
         np=np+1
         xx(np)=0d0
         yy(np)=dble(i-1)/dble(n)
         zz(np)=dble(j-1)/dble(n)
         rr(np)=r
         nb(np)=1
       enddo
       enddo

c      ��
       do i=2,n
       do j=2,n
         np=np+1
         xx(np)=1d0
         yy(np)=dble(i-1)/dble(n)
         zz(np)=dble(j-1)/dble(n)
         rr(np)=r
         nb(np)=1
       enddo
       enddo
c
       return
       end
c------------------------------------------------------------------
c
c       �f�[�^�쐬
c
c       �����A�߂�l
c       np    :�ߓ_��
c       xx(np):x���W
c       yy(np):y���W
c       zz(np):z���W
c       rr(np):�ߓ_���a
c       nb(np) 0:�����ߓ_,1:���E�ߓ_
c       r0    :��̐ߓ_���a
c       ind   :�ߓ_���̏��
c------------------------------------------------------------------
       subroutine data_cycle(np,xx,yy,zz,nb)
       implicit double precision(a-h,o-z)
       parameter(ind=14999)
       dimension xx(ind),yy(ind),zz(ind),rr(ind)
       dimension nb(ind)
       data PI/3.1415926535/   !�~����
c
c      �����ϐ�
c      int i,n
c      double shita

       np=0;

       n=62;

c      ���E�̐ߓ_
       do i=1,n
         shita=dble(i)/dble(n)*2d0*PI;

         np=np+1;
         xx(np)=0.5*dsin(shita);
         yy(np)=0.5*dcos(shita);
         zz(np)=0d0;
         nb(np)=1;
       enddo
c
       return;
       end
c------------------------------------------------------------------
c
c       �f�[�^�쐬
c
c       �����A�߂�l
c       np    :�ߓ_��
c       xx(np):x���W
c       yy(np):y���W
c       zz(np):z���W
c       rr(np):�ߓ_���a
c       nb(np) 0:�����ߓ_,1:���E�ߓ_
c       r0    :��̐ߓ_���a
c       ind   :�ߓ_���̏��
c------------------------------------------------------------------
       subroutine data_square5(np,xx,yy,zz,ind)
       implicit double precision(a-h,o-z)
       dimension xx(ind),yy(ind),zz(ind),rr(ind)
       dimension nb(ind)

       xx(0+1)=0
       xx(1+1)=0.013732
       xx(2+1)=0.031548
       xx(3+1)=0.051319
       xx(4+1)=0.072478
       xx(5+1)=0.094732
       xx(6+1)=0.1179
       xx(7+1)=0.141857
       xx(8+1)=0.166511
       xx(9+1)=0.19179
       xx(10+1)=0.217638
       xx(11+1)=0.244009
       xx(12+1)=0.270864
       xx(13+1)=0.298171
       xx(14+1)=0.325902
       xx(15+1)=0.354033
       xx(16+1)=0.382541
       xx(17+1)=0.411408
       xx(18+1)=0.440617
       xx(19+1)=0.470152
       xx(20+1)=0.5
       xx(21+1)=0
       xx(22+1)=0
       xx(23+1)=0
       xx(24+1)=0
       xx(25+1)=0
       xx(26+1)=0
       xx(27+1)=0
       xx(28+1)=0
       xx(29+1)=0
       xx(30+1)=0
       xx(31+1)=0
       xx(32+1)=0
       xx(33+1)=0
       xx(34+1)=0
       xx(35+1)=0
       xx(36+1)=0
       xx(37+1)=0
       xx(38+1)=0
       xx(39+1)=0
       xx(40+1)=0
       xx(41+1)=0.05
       xx(42+1)=0.1
       xx(43+1)=0.15
       xx(44+1)=0.2
       xx(45+1)=0.25
       xx(46+1)=0.3
       xx(47+1)=0.35
       xx(48+1)=0.4
       xx(49+1)=0.45
       xx(50+1)=0.5
       xx(51+1)=0.5
       xx(52+1)=0.5
       xx(53+1)=0.5
       xx(54+1)=0.5
       xx(55+1)=0.5
       xx(56+1)=0.5
       xx(57+1)=0.5
       xx(58+1)=0.5
       xx(59+1)=0.5

       yy(0+1)=0
       yy(1+1)=0
       yy(2+1)=0
       yy(3+1)=0
       yy(4+1)=0
       yy(5+1)=0
       yy(6+1)=0
       yy(7+1)=0
       yy(8+1)=0
       yy(9+1)=0
       yy(10+1)=0
       yy(11+1)=0
       yy(12+1)=0
       yy(13+1)=0
       yy(14+1)=0
       yy(15+1)=0
       yy(16+1)=0
       yy(17+1)=0
       yy(18+1)=0
       yy(19+1)=0
       yy(20+1)=0
       yy(21+1)=0.013732
       yy(22+1)=0.031548
       yy(23+1)=0.051319
       yy(24+1)=0.072478
       yy(25+1)=0.094732
       yy(26+1)=0.1179
       yy(27+1)=0.141857
       yy(28+1)=0.166511
       yy(29+1)=0.19179
       yy(30+1)=0.217638
       yy(31+1)=0.244009
       yy(32+1)=0.270864
       yy(33+1)=0.298171
       yy(34+1)=0.325902
       yy(35+1)=0.354033
       yy(36+1)=0.382541
       yy(37+1)=0.411408
       yy(38+1)=0.440617
       yy(39+1)=0.470152
       yy(40+1)=0.5
       yy(41+1)=0.5
       yy(42+1)=0.5
       yy(43+1)=0.5
       yy(44+1)=0.5
       yy(45+1)=0.5
       yy(46+1)=0.5
       yy(47+1)=0.5
       yy(48+1)=0.5
       yy(49+1)=0.5
       yy(50+1)=0.5
       yy(51+1)=0.05
       yy(52+1)=0.1
       yy(53+1)=0.15
       yy(54+1)=0.2
       yy(55+1)=0.25
       yy(56+1)=0.3
       yy(57+1)=0.35
       yy(58+1)=0.4
       yy(59+1)=0.45

       zz(0+1)=0
       zz(1+1)=0
       zz(2+1)=0
       zz(3+1)=0
       zz(4+1)=0
       zz(5+1)=0
       zz(6+1)=0
       zz(7+1)=0
       zz(8+1)=0
       zz(9+1)=0
       zz(10+1)=0
       zz(11+1)=0
       zz(12+1)=0
       zz(13+1)=0
       zz(14+1)=0
       zz(15+1)=0
       zz(16+1)=0
       zz(17+1)=0
       zz(18+1)=0
       zz(19+1)=0
       zz(20+1)=0
       zz(21+1)=0
       zz(22+1)=0
       zz(23+1)=0
       zz(24+1)=0
       zz(25+1)=0
       zz(26+1)=0
       zz(27+1)=0
       zz(28+1)=0
       zz(29+1)=0
       zz(30+1)=0
       zz(31+1)=0
       zz(32+1)=0
       zz(33+1)=0
       zz(34+1)=0
       zz(35+1)=0
       zz(36+1)=0
       zz(37+1)=0
       zz(38+1)=0
       zz(39+1)=0
       zz(40+1)=0
       zz(41+1)=0
       zz(42+1)=0
       zz(43+1)=0
       zz(44+1)=0
       zz(45+1)=0
       zz(46+1)=0
       zz(47+1)=0
       zz(48+1)=0
       zz(49+1)=0
       zz(50+1)=0
       zz(51+1)=0
       zz(52+1)=0
       zz(53+1)=0
       zz(54+1)=0
       zz(55+1)=0
       zz(56+1)=0
       zz(57+1)=0
       zz(58+1)=0
       zz(59+1)=0

       np=60

       return
       end
c------------------------------------------------------------------
c
c       �f�[�^�쐬
c
c       �����A�߂�l
c       np    :�ߓ_��
c       xx(np):x���W
c       yy(np):y���W
c       zz(np):z���W
c       ind   :�ߓ_���̏��
c------------------------------------------------------------------
       subroutine data_square4(np,xx,yy,zz,ind)
       implicit double precision(a-h,o-z)
       dimension xx(ind),yy(ind),zz(ind)
c
       np=0
c
       n=10	!������
c
c      ��
       do i=0,n-1
         np=np+1
         xx(np)=dble(i)/dble(n)
         yy(np)=0d0
         zz(np)=0d0
       enddo
c
c      ��
       do i=0,n-1
         np=np+1
         xx(np)=1d0
         yy(np)=dble(i)/dble(n)
         zz(np)=0d0
       enddo
c
c      ��
       do i=1,n
         np=np+1
         xx(np)=dble(i)/dble(n)
         yy(np)=1d0
         zz(np)=0d0
       enddo
c
c      �E
       do i=1,n
         np=np+1
         xx(np)=0d0
         yy(np)=dble(i)/dble(n)
         zz(np)=0d0
       enddo
c
       return
       end

