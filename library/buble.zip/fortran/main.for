       implicit double precision(a-h,o-z)
       parameter(ind=14999)
       dimension xx(ind),yy(ind), zz(ind),rr(ind)
       dimension nb(ind)
c
       data r0/0.02/   !���a�̎w�W:
c
c       �f�[�^��ǂݍ���
c       call data_square3(np,xx,yy,zz,rr,nb,r0,ind)   !3d
       call data_square4(np,xx,yy,zz,ind)   !�ߓ_���ψ�
c       call data_square5(np,xx,yy,zz,ind)   !�ߓ_���s�ψ�
c       call data_cycle(np,xx,yy,zz,nb)
c
c      ���E�̐ߓ_�����ɓ����̐ߓ_�𔭐�������
       call setnp(np,xx,yy,zz)
c
       stop
       end
c-------------------------------------------------------------------------
c
c       �O���[�o���ϐ�
c       np           :�ߓ_��
c       xx(np)       :x���W
c       yy(np)       :y���W
c       zz(np)       :z���W
c       rr(np)       :�ߓ_���a
c       nb(np)        0:�����̐ߓ_,1:���E�̐ߓ_
c       ns(np)       :���͂̐ߓ_��
c       ms(np,ns(np)):���͂̐ߓ_�ԍ� �ړ��x�N�g���p
c       nt(np)       :���͂̐ߓ_��
c       mt(np,nt(np)):���͂̐ߓ_�ԍ� �ߓ_�̒ǉ��E�폜�p
c       vx,vy,vz     :�ړ��x�N�g��
c
c       ���[�J���ϐ�
c       x0(ind),y0(ind),z0(ind),rr0(ind)
c       nb0(ind)
c       ns0(ind)
c       np0
c       kp
c       ic
c       i,j,k
c       dd
c       nd    :�폜����ߓ_��
c       md(nd):�폜����ߓ_�ԍ�
c       d,r
c
c      ******************************* 
c      z0[np0]=zz[i];			//2����
c      z0[np0]=zz[i]+rr[i]/2;	//3����
c
c      �ǉ��E�폜�̐ߓ_��
c      ���E�ߓ_�̐ߓ_���a
c      ******************************* 
c
c-------------------------------------------------------------------------
       subroutine setnp(np,xx,yy,zz)
       implicit double precision(a-h,o-z)
       parameter(ind=14999)
c
c      �O���ϐ�
       dimension xx(ind),yy(ind), zz(ind)
       dimension rr(ind)
       dimension nb(ind)
       dimension ns(ind),ms(ind,499)
       dimension nt(ind),mt(ind,499)
c      ���[�J���ϐ�
       dimension x0(ind),y0(ind),z0(ind),rr0(ind)
       dimension nb0(ind),ns0(ind)
       dimension md(ind)     !�폜����ߓ_
c
       data r0/0.02/   !���a�̎w�W:
       data re/0.2/    !���z�̎w�W:���ϔ��a��2�{
       data ve/0.1/    !�ߓ_�̈ړ���
c
c       ������
       ic=1;
c
       !���E�̐ߓ_���arr�����߂�
       !�߂�l:rr(np)
       call setr(np,xx,yy,zz,nb,rr)
c
c      �����̐ߓ_:2d
       np=np+1;
       xx(np)=0.4;
       yy(np)=0.5;
       zz(np)=0.0;
       rr(np)=r0;
       nb(np)=0;
c
c      �����̐ߓ_:3d
c       np=np+1
c       xx(np)=0.23
c       yy(np)=0.25
c       zz(np)=0.75
c       rr(np)=r0
c       nb(np)=0
c
c       �`��
       call plt(ic,np,xx,yy,zz,rr,nb,ind)

100    continue

       if(ic.eq.999)goto 200
       ic=ic+1
       write(*,*)"---------------------------------"
       write(*,*)"ic:",ic,"np:",np


       !���͂̐ߓ_:�ړ��x�N�g���p
       !�߂�l:ns(np),ms(np,ns(np))
       call surround(np,xx,yy,zz,ns,ms,re,ind)


       !rr�̕␳:�����̐ߓ_
       !�߂�l:rr(np)
       call revr(np,xx,yy,zz,nb,ns,ms,rr,ind)


       !���͂̐ߓ_:�ߓ_�ǉ��E�폜�p
       call surround2(np,xx,yy,zz,rr,nt,mt,ind)

         np0=0  !���₷�ߓ_
         nd=0  !�폜����ߓ_
         do i=1,np
         if(nb(i).eq.0)then

           !�폜
c           if(nt(i).gt.3)then
           if(nt(i).ge.5)then
c           if(nt(i).ge.10)then
             d=100.0
             do j=1,nt(i)
               k=mt(i,j)
               dd=dsqrt((xx(i)-xx(k))**2
     &                 +(yy(i)-yy(k))**2
     &                 +(zz(i)-zz(k))**2)
               dd=dd/(rr(i)+rr(k))
               if(dd.lt.d)then
                 d=dd
               endif
             enddo
             if(d.le.0.6)then
               write(*,*)"del_0",i
               nd=nd+1
               md(nd)=i
             endif
           endif


           !�ǉ�
           ich=0    !���͂̐ߓ_�ɋ��E�̐ߓ_���܂ނ��܂܂Ȃ���
           do j=1,ns(i)
             k=ms(i,j)
             if(nb(k).eq.1)ich=1
           enddo
c           if(nt(i).lt.2)then
           if(nt(i).lt.5 .and. ich.eq.0)then
c           if(nt(i).lt.10)then
             d=100.0
             do j=1,nt(i)
               k=mt(i,j)
               dd=dsqrt((xx(i)-xx(k))**2
     &                 +(yy(i)-yy(k))**2
     &                 +(zz(i)-zz(k))**2)
               dd=dd/(rr(i)+rr(k))
               if(dd.lt.d)d=dd
             enddo
             if(d.ge.0.8)then
               np0=np0+1
               x0(np0)=xx(i)+rr(i)/10.0  !2����
               y0(np0)=yy(i)+rr(i)/10.0
               z0(np0)=zz(i)
               rr0(np0)=rr(i)
               write(*,*)"add_0:",i,nb(i),x0(np0),y0(np0),z0(np0)
             endif
           endif
       !    write(*,*)"ar:",i,r
         endif
         enddo


         !�ߓ_�𑝂₷
         do kp=1,np0
           xx(np+kp)=x0(kp)
           yy(np+kp)=y0(kp)
           zz(np+kp)=z0(kp)
           rr(np+kp)=rr0(kp)
           nb(np+kp)=0
           ns(np+kp)=0
         enddo
         np=np+np0

         !�ߓ_�폜
         np0=np
         do kp=1,np
           x0(kp)=xx(kp)
           y0(kp)=yy(kp)
           z0(kp)=zz(kp)
           rr0(kp)=rr(kp)
           nb0(kp)=nb(kp)
           ns0(kp)=ns(kp)
         enddo

         if(nd.gt.0)nd=1    !�폜��1����
         np=0
         do kp=1,np0
           k=0
           do j=1,nd
             if(kp.eq.md(j))k=1 !�폜����ߓ_�͂Ƃ΂�
           enddo
           if(k.eq.0)then
             np=np+1
             xx(np)=x0(kp)
             yy(np)=y0(kp)
             zz(np)=z0(kp)
             rr(np)=rr0(kp)
             nb(np)=nb0(kp)
             ns(np)=ns0(kp)
           endif
         enddo


         !�X�V/////////////////////////////////

         !���͂̐ߓ_
         call surround(np,xx,yy,zz,ns,ms,re,ind)

         !rr�̕␳
         !�߂�l:rr(np)
         call revr(np,xx,yy,zz,nb,ns,ms,rr,ind)

         !/////////////////////////////////////


         !�`��
         call plt(ic,np,xx,yy,zz,rr,nb,ind)


         !�ߓ_�̈ړ�
         do kp=1,np

         !�����̐ߓ_���ړ�����
         if(nb(kp).eq.0)then

           write(*,*)"xx:",kp,sngl(xx(kp)),sngl(yy(kp)),sngl(zz(kp))
     &                        ,sngl(rr(kp))

           !�ߓ_�̈ړ����������߂�
           call cnavra(kp,xx,yy,zz,rr,ns,ms,vx,vy,vz,ve,nb,ind)

           xx(kp)=xx(kp)+vx
           yy(kp)=yy(kp)+vy
           zz(kp)=zz(kp)+vz
         endif
         enddo

         !��ԕ]��

         goto 100

200      continue

         !�t�@�C���̍쐬
         open(1,file='grid.inp')
         write(1,*)np
         do kp=1,np
           write(1,*)kp,sngl(xx(kp)),sngl(yy(kp)),sngl(zz(kp))
         enddo
c         
         return
         end
c-------------------------------------------------------------------------
c
c       �ߓ_�̈ړ��x�N�g�����v�Z����
c
c       kp    :�ߓ_
c       xx(np):x���W
c       yy(np):y���W
c       zz(np):z���W
c       rr(np):�ߓ_���a
c       ns(np):���͂̐ߓ_��
c       ms(np,ns(np)):���͂̐ߓ_�ԍ�
c       vx,vy,vz     :�ړ��x�N�g��
c       ve           :�ߓ_�̊�ړ���
c       nb(np)        0:�����̐ߓ_,1:���E�̐ߓ_
c       ind          :�ߓ_���̏��
c
c-------------------------------------------------------------------------
       subroutine cnavra(kp,xx,yy,zz,rr,ns,ms,vx,vy,vz,ve,nb,ind)
       implicit double precision(a-h,o-z)
       dimension xx(ind),yy(ind),zz(ind),rr(ind)
       dimension ns(ind),ms(ind,499)
       dimension nb(ind)

c         int kp
c         double x,y,z
c         double cx,cy,cz
c         double dx,dy,dz
c         double cc
c         double dd
c         int i,k

         x=xx(kp)
         y=yy(kp)
         z=zz(kp)

         cx=0.0
         cy=0.0
         cz=0.0

         !�����x�N�g��
         do i=1,ns(kp)
           k=ms(kp,i)

           dx=x-xx(k)  !�˗͕���
           dy=y-yy(k)
           dz=z-zz(k)

c           write(*,*)"dx:",kp,k,dx,dy,dz

           dd=dsqrt(dx**2+dy**2+dz**2)

           if(dd.le.0.000001)then
             dx=1.0
             dy=0.0
             dz=0.0
           else
             dx=dx/dd
             dy=dy/dd
             dz=dz/dd
           endif

           cc=dd/(rr(kp)+rr(k))

c           write(*,*)"cc:",kp,k,dd,rr(kp)+rr(k),cc,w(cc)

           cx=cx+w(cc,nb(k))*dx
           cy=cy+w(cc,nb(k))*dy
           cz=cz+w(cc,nb(k))*dz
         enddo

         cc=dsqrt(cx**2+cy**2+cz**2)

         if(cc.gt.0.0)then
           vx=ve*rr(kp)*cx/cc
           vy=ve*rr(kp)*cy/cc
           vz=ve*rr(kp)*cz/cc
         else
           vx=0.0
           vy=0.0
           vz=0.0
         endif

c         write(*,*)"vx:",vx,vy,vz,cc
c         pause

       return
       end
c-----------------------------------------------------------------------
c
c      �d�݊֐�
c        ���E�ߓ_�̐˗͂͑傫������
c
c-----------------------------------------------------------------------
       function w(cc,nb)
       implicit double precision(a-h,o-z)

         !�˗�
         if(cc.le.1.0)then
       !   w=-log10(cc+0.0001)
           if(nb.eq.0)w=-100.0*cc+100.0     !�����̐ߓ_
c           if(nb.eq.1)w=-1000.0*cc+1000.0   !���E�̐ߓ_
           if(nb.eq.1)w=1000.0   !���E�̐ߓ_

         !����
         elseif(cc.ge.1.0)then
       !   w=-log10(cc+0.0001)/10.0
           w=-0.01*cc+0.01
         endif

       end
c-----------------------------------------------------------------------
c
c      ���E�̐ߓ_���arr�����߂�
c
c-----------------------------------------------------------------------
       subroutine setr(np,xx,yy,zz,nb,rr)
       implicit double precision(a-h,o-z)
       parameter(ind=14999)
       dimension xx(ind),yy(ind),zz(ind),rr(ind)
       dimension nb(ind)
c
       do 100 i=1,np
         dmin=1000d0
         do 200 j=1,np
           if(i.eq.j)goto 200
           dd=dsqrt((xx(i)-xx(j))**2+(yy(i)-yy(j))**2+(zz(i)-zz(j))**2)
           if(dd.lt.dmin)dmin=dd
200      continue
         rr(i)=dmin/2d0
         nb(i)=1
c         write(*,*)"rr:",i,rr(i)
c         pause
100    continue
c
       return
       end
c-----------------------------------------------------------------------
c
c      ���͂̐ߓ_:�ߓ_���arr�̕␳�p
c
c-----------------------------------------------------------------------
       subroutine surround(np,xx,yy,zz,ns,ms,re,ind)
       implicit double precision(a-h,o-z)
       dimension xx(ind),yy(ind),zz(ind)
       dimension ns(ind),ms(ind,499)
c
       do i=1,np
           ns(i)=0
           do j=1,np
           if(i.ne.j)then
             dd=dsqrt((xx(i)-xx(j))**2
     &               +(yy(i)-yy(j))**2
     &               +(zz(i)-zz(j))**2)
             if(dd.le.re)then
               ns(i)=ns(i)+1  !���͂̐ߓ_�̐�
               ms(i,ns(i))=j  !���͂̐ߓ_�̔ԍ�
             endif
           endif
         enddo
       enddo
c
       return
       end
c-----------------------------------------------------------------------
c
c      ���͂̐ߓ_:�ߓ_�ǉ��E�폜�p
c
c-----------------------------------------------------------------------
       subroutine surround2(np,xx,yy,zz,rr,nt,mt,ind)
       implicit double precision(a-h,o-z)
       dimension xx(ind),yy(ind),zz(ind),rr(ind)
       dimension nt(ind),mt(ind,499)
c
       do i=1,np
         nt(i)=0
         do j=1,np
         if(i.ne.j)then
           dd=dsqrt((xx(i)-xx(j))**2+(yy(i)-yy(j))**2+(zz(i)-zz(j))**2)
           if(dd.le.rr(i)*2.1)then
             nt(i)=nt(i)+1  !���͂̐ߓ_�̐�
             mt(i,nt(i))=j  !���͂̐ߓ_�̔ԍ�
           endif
         endif
         enddo
       enddo
c
       return
       end
c-----------------------------------------------------------------------
c
c      �����ߓ_��rr�␳
c
c-----------------------------------------------------------------------
       subroutine revr(np,xx,yy,zz,nb,ns,ms,rr,ind)
       implicit double precision(a-h,o-z)
       dimension xx(ind),yy(ind),zz(ind),rr(ind)
       dimension ns(ind),ms(ind,499)
       dimension nb(ind)
c
       do i=1,np
       if(nb(i).eq.0 .and. ns(i).gt.0)then
         r = 0.0
         d = 0.0
         do j=1,ns(i)
           k=ms(i,j)
           dd=dsqrt((xx(i)-xx(k))**2+(yy(i)-yy(k))**2+(zz(i)-zz(k))**2)
           dd=1.0/(dd+0.001)
           d=d+dd
           r=r+rr(k)*dd
       !    write(*,*)"rr:",i,j,dd,rr(k)
         enddo
         dd=1.0/(0.0+0.001)
         d=d+dd
         r=r+rr(i)*dd
         rr(i)=r/d
       !  write(*,*)"r0:",i,r,d,r/d,rr(i)
       endif
       enddo
c
       return
       end
