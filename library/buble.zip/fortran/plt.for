
c--------------------------------------------------------------------------------------
c
c      �`��:OpenGL�p
c      ic    :�^�C���X�e�b�v
c      np    :�ߓ_��
c      xx(np):x���W
c      yy(np):y���W
c      zz(np):z���W
c      rr(np):�ߓ_���a
c      nb(np) 0:�����̐ߓ_,1:���E�̐ߓ_
c
c--------------------------------------------------------------------------------------
       subroutine plt(ic,np,xx,yy,zz,rr,nb,ind)
       implicit double precision(a-h,o-z)
       dimension xx(ind),yy(ind),zz(ind),rr(ind)
       dimension nb(ind)

c      �����ϐ�
c      int kp
       character*32 rfile,lpp
       character*32 fname
c
c       write(lpp,'(i4)')ic
c       do i=1,4
c         if(lpp(i:i).eq.' ') lpp(i:i)='0'
c       enddo
c       call addchr('res',lpp//'.inp',rfile)
c       write(*,*)rfile
       rfile=fname(ic)
c
       open(1,file=rfile)

       write(1,*)np+2
       do kp=1,np
         write(1,*)kp, xx(kp), yy(kp), zz(kp), rr(kp), 0
       enddo

c      ��̋�
       write(1,*)np+1, -0.5, -0.5, 0.0, 0.1, 0

c      ��̋�
       write(1,*)np+2, -0.7, -0.5, 0.0, 0.03, 0

       close(1)
       return
       end
c--------------------------------------------------------------------------------------
c
c      �`��:OpenGL�p(���E�ߓ_����)
c      ic    :�^�C���X�e�b�v
c      np    :�ߓ_��
c      xx(np):x���W
c      yy(np):y���W
c      zz(np):z���W
c      rr(np):�ߓ_���a
c      nb(np) 0:�����̐ߓ_,1:���E�̐ߓ_
c
c--------------------------------------------------------------------------------------
       subroutine plt_2(ic,np,xx,yy,zz,rr,nb,ind)
       implicit double precision(a-h,o-z)
       dimension xx(ind),yy(ind),zz(ind),rr(ind)
       dimension nb(ind)

c      �����ϐ�
c      int kp
       character*32 rfile,lpp
       character*32 fname
c       
c       write(lpp,'(i4)')ic
c       do i=1,4
c         if(lpp(i:i).eq.' ') lpp(i:i)='0'
c       enddo
c       call addchr('res',lpp//'.inp',rfile)
c       write(*,*)rfile
       rfile=fname(ic)

       n=0
       do kp=1,np
         if(nb(kp).ne.1)n=n+1
       enddo
c
       open(1,file=rfile)

       write(1,*)n+2
       n=0
       do kp=1,np
         if(nb(kp).ne.1)then
           write(1,*)n+1, xx(kp), yy(kp), zz(kp), rr(kp), 0
           n=n+1
         endif
       enddo

c      ��̋�
       write(1,*)n+1, -0.5, -0.5, 0.0, 0.1, 0

c      ��̋�
       write(1,*)n+2, -0.7, -0.5, 0.0, 0.03, 0

       close(1)
       return
       end
c--------------------------------------------------------------------------------------
c
c      �`��:AVS�p
c      ic    :�^�C���X�e�b�v
c      np    :�ߓ_��
c      xx(np):x���W
c      yy(np):y���W
c      zz(np):z���W
c      rr(np):�ߓ_���a
c      nb(np) 0:�����̐ߓ_,1:���E�̐ߓ_
c
c--------------------------------------------------------------------------------------
       subroutine plt_3(ic,np,xx,yy,zz,rr,nb,ind)
       implicit double precision(a-h,o-z)
       dimension xx(ind),yy(ind),zz(ind),rr(ind)
       dimension nb(ind)

c      �����ϐ�
c      int kp
       character*32 rfile,lpp
       character*32 fname
c      
c       write(lpp,'(i4)')ic
c       do i=1,4
c         if(lpp(i:i).eq.' ') lpp(i:i)='0'
c       enddo
c       call addchr('res',lpp//'.inp',rfile)
c       write(*,*)rfile
       rfile=fname(ic)
c
       open(1,file=rfile)

       write(1,'(A)')"1"
       write(1,'(A)')"data"
       write(1,'(A)')"step1"
       write(1,*)np,0
       do kp=1,np
         write(1,*)kp,sngl( xx(kp)), sngl(yy(kp)), sngl(zz(kp))
       enddo

       write(1,'(A)')"2 0"
       write(1,'(A)')"2 1 1"
       write(1,'(A)')"radian,"
       write(1,'(A)')"nc,"

       do kp=1,np
         write(1,*)kp, sngl(rr(kp)),0
       enddo

       close(1)
       return
       end
c--------------------------------------------------------------------------------------
c
c      �`��:AVS�p(���E�ߓ_����)
c      ic    :�^�C���X�e�b�v
c      np    :�ߓ_��
c      xx(np):x���W
c      yy(np):y���W
c      zz(np):z���W
c      rr(np):�ߓ_���a
c      nb(np) 0:�����̐ߓ_,1:���E�̐ߓ_
c
c--------------------------------------------------------------------------------------
       subroutine plt_4(ic,np,xx,yy,zz,rr,nb,ind)
       implicit double precision(a-h,o-z)
       dimension xx(ind),yy(ind),zz(ind),rr(ind)
       dimension nb(ind)

c      �����ϐ�
c      int kp
       character*32 rfile,lpp
       character*32 fname
c       
c       write(lpp,'(i4)')ic
c       do i=1,4
c         if(lpp(i:i).eq.' ') lpp(i:i)='0'
c       enddo
c       call addchr('res',lpp//'.inp',rfile)
c       write(*,*)rfile
       rfile=fname(ic)

       n=0
       do kp=1,np
         if(nb(kp).ne.1)n=n+1
       enddo
c
       open(1,file=rfile)

       write(1,'(A)')"1"
       write(1,'(A)')"data"
       write(1,'(A)')"step1"
       write(1,*)n,0

       n=0
       do kp=1,np
         if(nb(kp).ne.1)then
           write(1,*)n+1, sngl(xx(kp)), sngl(yy(kp)), sngl(zz(kp))
           n=n+1
         endif
       enddo

       write(1,'(A)')"2 0"
       write(1,'(A)')"2 1 1"
       write(1,'(A)')"radian,"
       write(1,'(A)')"nc,"

       n=0
       do kp=1,np
         if(nb(kp).ne.1)then
           write(1,*)n+1, sngl(rr(kp)), 0
           n=n+1
         endif
       enddo

       close(1)
       return
       end
